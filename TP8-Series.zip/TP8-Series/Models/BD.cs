using System.Runtime.InteropServices.ComTypes;
using System.IO.Compression;
using System.Security.Cryptography;
using System;
using System.Data;
using System.Data.Common;
using System.Collections.Generic;
using System.Linq;
using Dapper;
using System.Data.SqlClient;



namespace TP8_Series.Models
{
    public class BD
    {

        private static string _connectionString = @"Server = DESKTOP-1RNSEE0\SQLEXPRESS; DataBase=BDSeries;Trusted_Connection=True;";
        
        public static List<Actores> TraerActores(int idS)
        {
            using (SqlConnection db = new SqlConnection(_connectionString))
            {
                string sql = "SELECT * from Actores where idSerie = @pid";
                return db.Query<Actores>(sql, new {pid = idS }).ToList();
            }
            
        }
        public static List<Series> TraerSeries()
        {
            using (SqlConnection db = new SqlConnection(_connectionString))
            {
                string sql = "SELECT * from Series";
                return db.Query<Series>(sql).ToList();
            }
        }

        public static Series verInfoSerie(int idS)
        {
            Series serieActual = null;
            using (SqlConnection db = new SqlConnection(_connectionString))
            {
                string sql = "SELECT * FROM Series WHERE idSerie = @pid";
                serieActual = db.QueryFirstOrDefault<Series>(sql,new {pid = idS});
            }
            return serieActual;
        }
        public static List<Temporadas> TraerTemporadas(int idS)
        {
           using (SqlConnection db = new SqlConnection(_connectionString))
            {
                string sql = "SELECT * from Temporadas where idSerie = @pid";
                return db.Query<Temporadas>(sql, new {pid = idS }).ToList();
            }
        }








    }
}

